import { getUncachableStripeClient } from '../server/stripeClient';

async function createProducts() {
  const stripe = await getUncachableStripeClient();

  // Check if Pro product already exists
  const existingProducts = await stripe.products.search({ 
    query: "name:'CryptoMarket Pro'" 
  });

  if (existingProducts.data.length > 0) {
    console.log('Pro product already exists:', existingProducts.data[0].id);
    const prices = await stripe.prices.list({ product: existingProducts.data[0].id });
    console.log('Existing price:', prices.data[0]?.id);
    return;
  }

  // Create Pro product
  const product = await stripe.products.create({
    name: 'CryptoMarket Pro',
    description: 'Premium trading signals subscription with exclusive Pro signals, priority delivery, and advanced market analysis.',
    metadata: {
      tier: 'PRO',
      features: 'pro_signals,priority_delivery,advanced_analysis,full_history,email_notifications'
    }
  });

  console.log('Created product:', product.id);

  // Create monthly price ($29/month)
  const monthlyPrice = await stripe.prices.create({
    product: product.id,
    unit_amount: 2900, // $29.00
    currency: 'usd',
    recurring: { interval: 'month' },
    lookup_key: 'price_pro_monthly',
    metadata: {
      display_name: 'Pro Monthly'
    }
  });

  console.log('Created monthly price:', monthlyPrice.id);
  console.log('\nUpdate your Pricing.tsx to use this price ID:', monthlyPrice.id);
}

createProducts()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Error:', error);
    process.exit(1);
  });
