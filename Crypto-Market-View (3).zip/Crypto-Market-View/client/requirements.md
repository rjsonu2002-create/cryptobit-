## Packages
recharts | For drawing the price chart on the coin detail page

## Notes
- Using Google Fonts: 'Inter' for UI and 'JetBrains Mono' for numbers/prices
- Backend provides /api/coins and /api/coins/:symbol endpoints
- Images are placeholder URLs provided by the backend seed data
