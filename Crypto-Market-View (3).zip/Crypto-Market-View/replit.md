# CryptoBit - Cryptocurrency Price Tracker

## Overview

CryptoBit is a CoinMarketCap-style cryptocurrency tracker with live market data from CoinGecko API. It features user authentication via Replit Auth, trading signal subscriptions (Free and Pro tiers), and manual QR code payment via PhonePe. Users can view real-time crypto prices, access trading signals based on subscription level (blurred for FREE, unblurred for PRO), and upgrade to Pro (₹499/month) for exclusive premium signals. Admin manually verifies payments and upgrades user accounts.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, built using Vite
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **State Management**: TanStack React Query for server state and data fetching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Charts**: Recharts library for price visualization on coin detail pages

The frontend follows a component-based architecture with:
- Pages in `client/src/pages/` (Home, CoinDetail, not-found)
- Reusable components in `client/src/components/`
- Custom hooks in `client/src/hooks/` for data fetching and mobile detection
- UI primitives in `client/src/components/ui/` (shadcn/ui components)

### Backend Architecture
- **Framework**: Express.js 5 with TypeScript
- **Server**: Node.js with HTTP server
- **Build Tool**: esbuild for production server bundling, Vite for client

The backend serves as a proxy to the CoinGecko API with endpoints:
- `GET /api/markets` - Fetches top 10 cryptocurrencies by market cap
- `GET /api/coin/:id` - Fetches detailed information for a specific coin

### Data Storage
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema**: Defined in `shared/schema.ts` with a `coins` table (currently unused as data comes from CoinGecko)
- **Database**: PostgreSQL (requires DATABASE_URL environment variable)

Note: The current implementation fetches live data from CoinGecko API. The database schema and storage layer exist but are not actively used for the main functionality.

### Development vs Production
- Development: Vite dev server with HMR, proxied through Express
- Production: Static file serving from `dist/public` directory

## External Dependencies

### External APIs
- **CoinGecko API**: Free cryptocurrency market data API (https://api.coingecko.com/api/v3)
  - `/coins/markets` - Market data for multiple coins
  - `/coins/{id}` - Detailed coin information

### Database
- **PostgreSQL**: Required for session storage and potential future data persistence
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### Key NPM Packages
- `@tanstack/react-query`: Data fetching and caching
- `drizzle-orm` / `drizzle-kit`: Database ORM and migrations
- `recharts`: Charting library for price graphs
- `wouter`: Lightweight React router
- `zod`: Schema validation
- `class-variance-authority`: Component variant styling
- `lucide-react`: Icon library
- `stripe`: Stripe SDK for payment processing
- `stripe-replit-sync`: Automatic Stripe webhook and data sync

### Fonts (Google Fonts)
- Inter: Primary UI font
- JetBrains Mono: Monospace font for prices/numbers

## Authentication & Payments

### Replit Auth Integration
- Users can log in via social providers (Google, GitHub, X, Apple) or email
- Session-based authentication using PostgreSQL session store
- User data stored in `users` table with role-based access control

### Manual Payment System (PhonePe QR)
- **Payment Method**: Manual QR code payment via PhonePe (₹499/month)
- **QR Code Image**: `client/src/assets/payment-qr.jpeg` (displayed on /pricing page)
- **Payment Flow**:
  1. User scans QR code and pays ₹499 via PhonePe
  2. User uploads payment screenshot on the pricing page
  3. System generates a unique reference number (PAY-XXXXX-XXXX)
  4. Admin reviews screenshot in admin panel and approves/rejects
  5. Upon approval, user is automatically upgraded to PRO role
- **Pricing Page**: `/pricing` - Shows payment QR code, screenshot upload, and submission history
- **File Uploads**: Screenshots stored in `uploads/payments/` directory, served via `/uploads/` route

### Payment Submission Database
- **Table**: `payment_submissions`
- **Fields**: id, userId, userEmail, userName, referenceNumber, screenshotUrl, status (PENDING/APPROVED/REJECTED), adminNotes, createdAt, processedAt

### User Roles
- **FREE**: Access to free trading signals (Pro signals blurred)
- **PRO**: Access to all trading signals unblurred, priority delivery (₹499/month)
- **ADMIN**: Full access to all features + admin panel

### Signal Blurring
- FREE users see Pro signal values (entry, stopLoss, takeProfits, leverage) blurred
- PRO and ADMIN users see all signal values unblurred
- BlurredValue component uses blur-sm CSS class for hiding sensitive data

### API Routes
- `GET /api/auth/user` - Get current authenticated user
- `GET /api/stripe/products` - List products with prices
- `POST /api/stripe/checkout` - Create checkout session (requires auth)
- `POST /api/stripe/portal` - Create customer portal session (requires auth)
- `GET /api/signals?tier=FREE|PRO` - Get trading signals by tier
- `GET /api/markets` - Fetch top 10 cryptocurrencies
- `GET /api/coin/:id` - Fetch single coin details

### Admin Panel
- **URL**: `/admin` - Admin login and dashboard
- **Authentication**: Password-based via `ADMIN_PASSWORD` environment variable
- **Default Password**: "cryptobit2024" (can be overridden by env var)
- **Admin Routes** (protected by isAdmin middleware):
  - `POST /api/admin/login` - Authenticate admin
  - `GET /api/admin/stats` - Admin statistics
  - `GET /api/admin/users` - List all users
  - `POST /api/admin/users/role` - Update user role (FREE/PRO/ADMIN)
  - `GET /api/admin/signals` - List all signals
  - `POST /api/admin/signals` - Create new signal
  - `DELETE /api/admin/signals/:id` - Delete signal
- Admin frontend sends password in `x-admin-auth` header for all protected API requests

## Signal Engine

### Automatic Trade Monitoring
- **Signal Engine** (`server/signalEngine.ts`): Runs every 30 seconds to evaluate active signals
- **Price Fetcher** (`server/coingecko.ts`): Fetches live prices from CoinGecko with 30-second cache TTL
- **Coin ID Mapping**: Supports 70+ cryptocurrencies (BTC→bitcoin, ETH→ethereum, SOL→solana, etc.)

### Signal Evaluation Logic
- Evaluates ACTIVE signals against live CoinGecko prices
- Direction-aware closing:
  - **LONG signals**: Win (HIT) when price >= takeProfit, Loss (STOPPED) when price <= stopLoss
  - **SHORT signals**: Win (HIT) when price <= takeProfit, Loss (STOPPED) when price >= stopLoss
- Automatically updates signals with exitPrice, profitPercent/lossPercent, and closedAt timestamp

### Admin Signal Creation
- **Endpoint**: `POST /api/admin/signal`
- **Authentication**: Requires `x-admin-key` header matching `ADMIN_KEY` environment variable
- **Required fields**: pair, direction, entryPrice, stopLoss, takeProfit
- **Optional fields**: leverage, visibility (FREE/PRO)

### Signal Schema Fields
- `entryPrice`, `stopLossPrice`, `takeProfitPrice`: Precise numeric strings for calculations
- `exitPrice`: Set when signal closes
- `coinId`: CoinGecko coin ID for price lookups
- `visibility`: FREE or PRO (determines which users can see the signal)
- `status`: ACTIVE, HIT (take profit hit), STOPPED (stop loss hit)
- `profitPercent`, `lossPercent`: Calculated when signal closes
- `closedAt`: Timestamp when signal was closed

## Important Design Decisions

1. **Webhook ordering**: The Stripe webhook route MUST be registered before express.json() to receive raw Buffer payload for signature verification
2. **No stripe schema modifications**: Never create tables in the `stripe` schema - it's managed automatically by stripe-replit-sync
3. **Dynamic price fetching**: Pricing page fetches prices from /api/stripe/products instead of hardcoding
4. **CoinGecko free API**: Uses the free public CoinGecko API (no key required), data refreshes every 60 seconds
5. **Signal engine auto-start**: Signal engine starts automatically when server initializes via `startSignalEngine(30000)` in routes.ts
6. **Price caching**: CoinGecko prices are cached with 30-second TTL to avoid API rate limits