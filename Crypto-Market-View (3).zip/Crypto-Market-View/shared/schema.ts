import { pgTable, text, serial, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/auth";

export const coins = pgTable("coins", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  symbol: text("symbol").notNull().unique(),
  price: numeric("price").notNull(),
  change24h: numeric("change_24h").notNull(),
  marketCap: numeric("market_cap").notNull(),
  volume24h: numeric("volume_24h").notNull(),
  logoUrl: text("logo_url").notNull(),
});

export const insertCoinSchema = createInsertSchema(coins).omit({ id: true });

export type Coin = typeof coins.$inferSelect;
export type InsertCoin = z.infer<typeof insertCoinSchema>;

export const signals = pgTable("signals", {
  id: serial("id").primaryKey(),
  pair: text("pair").notNull(),
  coinId: text("coin_id"),
  direction: text("direction").notNull(),
  entry: text("entry").notNull(),
  stopLoss: text("stop_loss").notNull(),
  takeProfits: text("take_profits").notNull(),
  leverage: text("leverage").notNull(),
  entryPrice: numeric("entry_price"),
  stopLossPrice: numeric("stop_loss_price"),
  takeProfitPrice: numeric("take_profit_price"),
  exitPrice: numeric("exit_price"),
  status: text("status").notNull().default("ACTIVE"),
  tier: text("tier").notNull().default("FREE"),
  visibility: text("visibility").notNull().default("FREE"),
  profitPercent: numeric("profit_percent"),
  lossPercent: numeric("loss_percent"),
  closedAt: timestamp("closed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSignalSchema = createInsertSchema(signals).omit({ id: true, createdAt: true });

export type Signal = typeof signals.$inferSelect;
export type InsertSignal = z.infer<typeof insertSignalSchema>;

export type CoinResponse = Coin;
export type CoinListResponse = Coin[];

export const paymentSubmissions = pgTable("payment_submissions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  userEmail: text("user_email"),
  userName: text("user_name"),
  referenceNumber: text("reference_number").notNull().unique(),
  screenshotUrl: text("screenshot_url").notNull(),
  status: text("status").notNull().default("PENDING"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  processedAt: timestamp("processed_at"),
});

export const insertPaymentSubmissionSchema = createInsertSchema(paymentSubmissions).omit({ id: true, createdAt: true, processedAt: true });

export type PaymentSubmission = typeof paymentSubmissions.$inferSelect;
export type InsertPaymentSubmission = z.infer<typeof insertPaymentSubmissionSchema>;

export const portfolioHoldings = pgTable("portfolio_holdings", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  coinId: text("coin_id").notNull(),
  coinName: text("coin_name").notNull(),
  coinSymbol: text("coin_symbol").notNull(),
  coinImage: text("coin_image"),
  quantity: numeric("quantity").notNull(),
  buyPrice: numeric("buy_price").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertPortfolioHoldingSchema = createInsertSchema(portfolioHoldings).omit({ id: true, createdAt: true, updatedAt: true });

export type PortfolioHolding = typeof portfolioHoldings.$inferSelect;
export type InsertPortfolioHolding = z.infer<typeof insertPortfolioHoldingSchema>;
